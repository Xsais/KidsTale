//
//  StoreDataClass.swift
//  IOSFinalProjectStoreDetails
//
//  Created by Xcode User on 2020-04-11.
//  Copyright © 2020 Xcode User. All rights reserved.
//

import UIKit

class StoreDataClass: NSObject {
    var StoreDataId : Int?
    var StoreNameString : String?
    var StoreHourString : String?
    var StoreImageString : String?
    var StoreLocationString : String?
    var StoreDescriptionString : String?
    
       //create table StoreInfo(ID integer Primary key, StoreName text, StoreLocation text, StoreDescription text, StoreHour text,StoreImage text);
    
    func initWithData(theRow i : Int, storeName : String, storeLocation : String, storeDescription : String, storeHour : String, storeImage : String){
        
        StoreDataId = i
        StoreNameString = storeName
        StoreLocationString = storeLocation
        StoreDescriptionString = storeDescription
        StoreHourString = storeHour
        StoreImageString = storeImage
        
    }
    
}
