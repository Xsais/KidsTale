//
//  AppDelegate.swift
//  IOSFinalProjectStoreDetails
//
//  Created by Xcode User on 2020-04-11.
//  Copyright © 2020 Xcode User. All rights reserved.
//

import UIKit
import SQLite3

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var databaseName : String? = "FinalDatbase.db"
    var databasePath : String?
    var storeData : [StoreDataClass] = []

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
       let documentPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDir = documentPaths[0]
        databasePath = documentsDir.appending("/" + databaseName!)
         checkAndCreateDatabase()
        readDataFromDatabase()  
        return true
    }
    
   func checkAndCreateDatabase(){
        var success = false
        let fileManager = FileManager.default
        success = fileManager.fileExists(atPath: databasePath!)
        if success {
            return
        }
        let databasePathFromApp = Bundle.main.resourcePath?.appending("/" + databaseName!)
    
        try? fileManager.copyItem(atPath: databasePathFromApp!, toPath: databasePath!)
        
        return
    }
    
    func readDataFromDatabase(){
        storeData.removeAll()
        var db : OpaquePointer? = nil
        if sqlite3_open(self.databasePath, &db) == SQLITE_OK {
            
            var queryStatement : OpaquePointer? = nil
            var queryStatementString : String = "Select * from StoreInfo"
            
            //create table StoreInfo(ID integer Primary key, StoreName text, StoreLocation text, StoreDescription text, StoreHour text,StoreImage text);

            if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil)
                == SQLITE_OK{
                while sqlite3_step(queryStatement) == SQLITE_ROW{
                    //extract the row to the data object
                    let id : Int = Int(sqlite3_column_int(queryStatement, 0))
                    let cstorename = sqlite3_column_text(queryStatement, 1)
                    let cstorelocation = sqlite3_column_text(queryStatement, 2)
                    let cdescription = sqlite3_column_text(queryStatement, 3)
                      let cstorehour = sqlite3_column_text(queryStatement, 4)
                     let cstoreimage = sqlite3_column_text(queryStatement, 5)
                    
                    let storename = String(cString: cstorename!)
                    let storelocation = String(cString: cstorelocation!)
                    let storedescription = String(cString: cdescription!)
                     let storehour = String(cString: cstorehour!)
                    let storeimage = String(cString: cstoreimage!)
                    
                    
                    let data : StoreDataClass = StoreDataClass.init()
                        data.initWithData(theRow: id, storeName: storename, storeLocation: storelocation, storeDescription: storedescription, storeHour: storehour, storeImage: storeimage)
                    storeData.append(data)
                    print("query result")
                    print("\(id) | \(storename) | \(storelocation) | \(storedescription)")
                    
                }
                sqlite3_finalize(queryStatement)
            }else{
                print("Unable to open database1")
            }
            sqlite3_close(db)
        }else{
            print("Unable to open database2")
        }
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

