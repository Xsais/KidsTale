# KidsTale
The purpose of this project is to develop a mobile IOS application, that is used by bookstores. This application primarily is targeted towards children. Children's books do not have to be expensive, together through our KidsTale application we can make children’s books accessible, affordable and make a difference in children's literacy skills with one tale at a time.
